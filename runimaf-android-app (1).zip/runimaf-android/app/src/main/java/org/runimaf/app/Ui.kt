@file:OptIn(ExperimentalMaterial3Api::class)

package org.runimaf.app

import android.content.Intent
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage

// رنگ‌های وب‌سایت رونی‌ماف
val Navy = Color(0xFF0B1F3A)
val Navy2 = Color(0xFF16355F)
val Green = Color(0xFF1F8A70)
val Gold = Color(0xFFE3A72F)
val Muted = Color(0xFF5B6B82)
val Bg = Color(0xFFF5F7FA)

private val Colors = lightColorScheme(
    primary = Navy, secondary = Green, tertiary = Gold,
    background = Bg, surface = Color.White, onPrimary = Color.White,
    secondaryContainer = Color(0xFFE6F4F0), onSecondaryContainer = Navy,
)

enum class Tab(val key: String, val icon: ImageVector) {
    HOME("tab_home", Icons.Filled.Home),
    ARTICLES("tab_articles", Icons.Filled.Menu),
    MEDIA("tab_media", Icons.Filled.PlayArrow),
    MORE("tab_more", Icons.Filled.Settings),
}

@Composable
fun RunimafApp() {
    val ctx = LocalContext.current
    var lang by remember { mutableStateOf(Prefs.lang(ctx)) }
    val dir = if (lang == "en") LayoutDirection.Ltr else LayoutDirection.Rtl
    CompositionLocalProvider(LocalLayoutDirection provides dir) {
        MaterialTheme(colorScheme = Colors) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                AppScaffold(lang) { lang = it; Prefs.setLang(ctx, it) }
            }
        }
    }
}

@Composable
fun AppScaffold(lang: String, onLang: (String) -> Unit) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var detail by remember { mutableStateOf<Item?>(null) }
    BackHandler(enabled = detail != null) { detail = null }

    val d = detail
    if (d != null) {
        DetailScreen(d, lang) { detail = null }
        return
    }
    val open: (Item) -> Unit = { detail = it }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(Str.t(lang, "app_name"), fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                Tab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = null) },
                        label = { Text(Str.t(lang, t.key), maxLines = 1) },
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                Tab.HOME -> HomeScreen(lang, open, { tab = Tab.ARTICLES }, { tab = Tab.MEDIA })
                Tab.ARTICLES -> FeedScreen("posts", "categories", "categories", lang, open)
                Tab.MEDIA -> FeedScreen("runimaf_media", "media_type", "media_type", lang, open)
                Tab.MORE -> MoreScreen(lang, onLang)
            }
        }
    }
}

@Composable
fun Banner(lang: String) {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Navy, Navy2)))
            .padding(20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        AsyncImage(
            model = Api.LOGO, contentDescription = null,
            placeholder = painterResource(R.drawable.ic_logo), error = painterResource(R.drawable.ic_logo),
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(84.dp).clip(RoundedCornerShape(16.dp)),
        )
        Column {
            Text(Str.t(lang, "app_name"), color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
            Text(Str.t(lang, "tagline"), color = Gold, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp),
        color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
}

@Composable
fun ItemCard(item: Item, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp),
    ) {
        Column {
            item.image()?.let {
                AsyncImage(model = it, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(170.dp))
            }
            Column(Modifier.padding(14.dp)) {
                Text(item.dateText(), color = Muted, style = MaterialTheme.typography.labelSmall)
                Text(item.titleText(), color = Navy, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 3)
                Spacer(Modifier.height(4.dp))
                Text(item.excerptText(), color = Muted, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
            }
        }
    }
}

@Composable
fun HomeScreen(lang: String, open: (Item) -> Unit, goPosts: () -> Unit, goMedia: () -> Unit) {
    val posts: FeedViewModel = viewModel(key = "home_posts")
    val media: FeedViewModel = viewModel(key = "home_media")
    LaunchedEffect(lang) {
        posts.load("posts", lang, "")
        media.load("runimaf_media", lang, "")
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { Banner(lang) }
        item { SectionTitle(Str.t(lang, "latest_articles")) }
        items(posts.items.take(3), key = { "p${it.id}" }) { ItemCard(it) { open(it) } }
        item { TextButton(onClick = goPosts, modifier = Modifier.padding(horizontal = 8.dp)) { Text(Str.t(lang, "all")) } }
        item { SectionTitle(Str.t(lang, "latest_media")) }
        items(media.items.take(3), key = { "m${it.id}" }) { ItemCard(it) { open(it) } }
        item { TextButton(onClick = goMedia, modifier = Modifier.padding(horizontal = 8.dp)) { Text(Str.t(lang, "all")) } }
        item {
            if (posts.loading || media.loading) {
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            }
        }
    }
}

@Composable
fun FeedScreen(path: String, termPath: String, filterParam: String, lang: String, open: (Item) -> Unit) {
    val vm: FeedViewModel = viewModel(key = path)
    var terms by remember(lang) { mutableStateOf<List<Term>>(emptyList()) }
    var sel by remember(lang) { mutableStateOf(0) }
    LaunchedEffect(lang) {
        terms = try { Api.terms(termPath, Api.slug(lang)) } catch (e: Exception) { emptyList() }
    }
    val extra = if (sel != 0) "&$filterParam=$sel" else ""
    LaunchedEffect(lang, extra) { vm.load(path, lang, extra) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected = sel == 0, onClick = { sel = 0 }, label = { Text(Str.t(lang, "all")) }) }
                items(terms, key = { it.id }) { t ->
                    FilterChip(selected = sel == t.id, onClick = { sel = t.id }, label = { Text(clean(t.name)) })
                }
            }
        }
        items(vm.items, key = { "$path${it.id}" }) { ItemCard(it) { open(it) } }
        item {
            Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                when {
                    vm.loading -> CircularProgressIndicator()
                    vm.error -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(Str.t(lang, "error_load"), color = Muted)
                        Button(onClick = { vm.retry() }) { Text(Str.t(lang, "retry")) }
                    }
                    vm.hasMore -> OutlinedButton(onClick = { vm.more() }) { Text(Str.t(lang, "load_more")) }
                    vm.items.isEmpty() -> Text(Str.t(lang, "empty"), color = Muted)
                }
            }
        }
    }
}

@Composable
fun DetailScreen(item: Item, lang: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val html = remember(item, lang) { Html.page(item, lang) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(Str.t(lang, "app_name")) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = Str.t(lang, "back")) }
                },
                actions = {
                    IconButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, item.link)
                        }
                        ctx.startActivity(Intent.createChooser(send, null))
                    }) { Icon(Icons.Filled.Share, contentDescription = Str.t(lang, "share")) }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Navy, titleContentColor = Color.White,
                    navigationIconContentColor = Color.White, actionIconContentColor = Color.White,
                ),
            )
        },
    ) { pad -> Box(Modifier.padding(pad)) { HtmlView(html) } }
}

@Composable
fun HtmlView(html: String) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true       // لازم برای پخش‌کننده‌های یوتیوب و آپارات
                settings.domStorageEnabled = true
                settings.allowFileAccess = false
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        if (!request.isForMainFrame) return false
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, request.url))   // لینک‌های بیرونی در مرورگر باز شوند
                        return true
                    }
                }
            }
        },
        update = { wv ->
            if (wv.tag != html) {
                wv.tag = html
                wv.loadDataWithBaseURL(Api.SITE, html, "text/html", "utf-8", null)
            }
        },
    )
}

@Composable
fun MoreScreen(lang: String, onLang: (String) -> Unit) {
    val uri = LocalUriHandler.current
    val social = listOf(
        "Telegram" to "https://t.me/runimaf",
        "Instagram" to "https://www.instagram.com/runimafkurdistan936",
        "X" to "https://x.com/runi_maf",
        "Facebook" to "https://www.facebook.com/runimafkurdistan936",
    )
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(Str.t(lang, "language"), color = Navy, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("fa" to "فارسی", "ku" to "کوردی", "en" to "English").forEach { (code, name) ->
                    FilterChip(selected = lang == code, onClick = { onLang(code) }, label = { Text(name) })
                }
            }
        }
        item { Text(Str.t(lang, "follow"), color = Navy, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(social, key = { it.first }) { (name, url) ->
            OutlinedButton(onClick = { uri.openUri(url) }, modifier = Modifier.fillMaxWidth()) { Text(name) }
        }
        item {
            Button(onClick = { uri.openUri(Api.SITE) }, modifier = Modifier.fillMaxWidth()) { Text(Str.t(lang, "website")) }
        }
    }
}
