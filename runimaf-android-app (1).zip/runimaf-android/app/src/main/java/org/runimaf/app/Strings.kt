package org.runimaf.app

import android.content.Context
import java.util.Locale

// ترتیب: فارسی، کوردی سورانی، انگلیسی (ترجمه‌ی کوردی را یک کردی‌زبان بازبینی کند)
object Str {
    private val m: Map<String, Array<String>> = mapOf(
        "app_name" to arrayOf("رونی‌ماف", "ڕوونی ماف", "RûniMaf"),
        "tagline" to arrayOf("آموزش حقوق بشر و حقوق شهروندی", "فێرکاریی مافی مرۆڤ و مافی هاوڵاتیبوون", "Human rights and citizenship education"),
        "tab_home" to arrayOf("خانه", "ماڵەوە", "Home"),
        "tab_articles" to arrayOf("مطالب", "بابەتەکان", "Articles"),
        "tab_media" to arrayOf("پادکست و فیلم", "پۆدکاست و فیلم", "Podcasts & Videos"),
        "tab_more" to arrayOf("بیشتر", "زیاتر", "More"),
        "latest_articles" to arrayOf("تازه‌ترین نوشته‌ها", "نوێترین بابەتەکان", "Latest articles"),
        "latest_media" to arrayOf("پادکست و فیلم‌های آموزشی", "پۆدکاست و فیلمە فێرکارییەکان", "Educational podcasts & videos"),
        "all" to arrayOf("همه", "هەموو", "All"),
        "load_more" to arrayOf("مطالب بیشتر", "بابەتی زیاتر", "Load more"),
        "retry" to arrayOf("تلاش دوباره", "دووبارە هەوڵ بدەرەوە", "Try again"),
        "error_load" to arrayOf("بارگذاری نشد. اینترنت را بررسی کنید.", "بارنەکرا. ئینتەرنێتەکەت بپشکنە.", "Could not load. Check your connection."),
        "empty" to arrayOf("مطلبی پیدا نشد.", "هیچ بابەتێک نەدۆزرایەوە.", "Nothing found."),
        "language" to arrayOf("زبان", "زمان", "Language"),
        "follow" to arrayOf("ما را دنبال کنید", "بەدوامان بکەوە", "Follow us"),
        "website" to arrayOf("وب‌سایت رونی‌ماف", "ماڵپەڕی ڕوونی ماف", "RûniMaf website"),
        "share" to arrayOf("اشتراک‌گذاری", "هاوبەشکردن", "Share"),
        "back" to arrayOf("بازگشت", "گەڕانەوە", "Back"),
    )
    fun t(lang: String, key: String): String {
        val i = when (lang) { "fa" -> 0; "ku" -> 1; else -> 2 }
        return m[key]?.get(i) ?: key
    }
}

object Prefs {
    fun lang(c: Context): String =
        c.getSharedPreferences("runimaf", Context.MODE_PRIVATE).getString("lang", null)
            ?: when (Locale.getDefault().language) { "ckb", "ku" -> "ku"; "en" -> "en"; else -> "fa" }

    fun setLang(c: Context, l: String) {
        c.getSharedPreferences("runimaf", Context.MODE_PRIVATE).edit().putString("lang", l).apply()
    }
}
