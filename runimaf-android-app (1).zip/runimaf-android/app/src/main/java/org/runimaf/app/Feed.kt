package org.runimaf.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class FeedViewModel : ViewModel() {
    var items by mutableStateOf<List<Item>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf(false); private set
    var hasMore by mutableStateOf(false); private set

    private var page = 0
    private var key = ""
    private var path = ""
    private var lang = "fa"
    private var extra = ""
    private var job: Job? = null

    fun load(path: String, lang: String, extra: String) {
        val k = "$path|$lang|$extra"
        if (k == key) return
        job?.cancel()
        key = k; this.path = path; this.lang = lang; this.extra = extra
        items = emptyList(); page = 0; hasMore = false; error = false; loading = false
        fetch()
    }

    fun more() = fetch()
    fun retry() = fetch()

    private fun fetch() {
        if (loading) return
        loading = true; error = false
        val requestKey = key
        job = viewModelScope.launch {
            try {
                val (list, total) = Api.items(path, Api.slug(lang), page + 1, extra)
                if (requestKey == key) { items = items + list; page += 1; hasMore = page < total }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (requestKey == key) error = true
            } finally {
                if (requestKey == key) loading = false
            }
        }
    }
}
