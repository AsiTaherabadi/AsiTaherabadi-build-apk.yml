package org.runimaf.app

import android.text.TextUtils

// ساخت پخش‌کننده برای لینک پادکست/فیلم (همان منطق وب‌سایت)
object MediaEmbed {
    private val yt = Regex("""(?:youtube\.com/watch\?(?:.*&)?v=|youtu\.be/|youtube\.com/embed/)([\w-]{11})""")
    private val ap = Regex("""aparat\.com/v/(\w+)""")
    private val audio = Regex("""\.(mp3|m4a|ogg|wav)(\?.*)?$""", RegexOption.IGNORE_CASE)
    private val video = Regex("""\.(mp4|webm)(\?.*)?$""", RegexOption.IGNORE_CASE)

    fun html(url: String): String {
        yt.find(url)?.let {
            return "<div class='embed'><iframe src='https://www.youtube-nocookie.com/embed/${it.groupValues[1]}' allowfullscreen></iframe></div>"
        }
        ap.find(url)?.let {
            return "<div class='embed'><iframe src='https://www.aparat.com/video/video/embed/videohash/${it.groupValues[1]}/vt/frame' allowfullscreen></iframe></div>"
        }
        val safe = TextUtils.htmlEncode(url)
        if (audio.containsMatchIn(url)) return "<audio controls style='width:100%' src='$safe'></audio>"
        if (video.containsMatchIn(url)) return "<video controls style='width:100%' src='$safe'></video>"
        return "<p><a href='$safe'>$safe</a></p>"
    }
}

object Html {
    fun page(item: Item, lang: String): String {
        val dir = if (lang == "en") "ltr" else "rtl"
        val img = item.image()?.let { "<img src='${TextUtils.htmlEncode(it)}'>" } ?: ""
        val embed = item.mediaUrl?.takeIf { it.isNotBlank() }?.let { MediaEmbed.html(it) } ?: ""
        return """<!doctype html><html lang="$lang" dir="$dir"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{font-family:sans-serif;line-height:1.9;margin:16px;color:#10213a;background:#fff;word-wrap:break-word}
img{max-width:100%;height:auto;border-radius:12px}
h1{font-size:1.35rem;color:#0b1f3a;line-height:1.6}
a{color:#1f8a70}
.embed{position:relative;padding-top:56.25%;margin:14px 0;border-radius:12px;overflow:hidden;background:#000}
.embed iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:0}
</style></head><body>
<h1>${TextUtils.htmlEncode(item.titleText())}</h1>$img$embed${item.content.rendered}
</body></html>"""
    }
}
