package org.runimaf.app

import android.content.Context
import androidx.core.text.HtmlCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.Cache
import okhttp3.CacheControl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

@Serializable data class Rendered(val rendered: String = "")

@Serializable
data class Item(
    val id: Int,
    val date: String = "",
    val link: String = "",
    val title: Rendered = Rendered(),
    val excerpt: Rendered = Rendered(),
    val content: Rendered = Rendered(),
    @SerialName("media_url") val mediaUrl: String? = null,
    @SerialName("_embedded") val embedded: JsonObject? = null,
) {
    fun titleText(): String = clean(title.rendered)
    fun excerptText(): String = clean(excerpt.rendered)
    fun dateText(): String = date.take(10)
    fun image(): String? = try {
        embedded?.get("wp:featuredmedia")?.jsonArray?.firstOrNull()?.jsonObject?.get("source_url")?.jsonPrimitive?.contentOrNull
    } catch (e: Exception) { null }
}

@Serializable data class Term(val id: Int, val name: String = "", val count: Int = 0)

fun clean(s: String): String =
    HtmlCompat.fromHtml(s, HtmlCompat.FROM_HTML_MODE_LEGACY).toString().replace('\uFFFC', ' ').trim()

object Api {
    // آدرس سایت: هر مطلبی که در سایت منتشر شود، همان لحظه در اپلیکیشن هم دیده می‌شود
    const val SITE = "https://runimaf.org"
    const val LOGO = "$SITE/wp-content/themes/runimaf-theme-v2/assets/images/runimaf-logo.jpg"   // لوگوی فعلی سایت؛ اگر جابه‌جا شد اینجا عوض کنید
    private const val BASE = "$SITE/wp-json/wp/v2/"

    // نام زبان‌ها در Polylang (اگر نامک زبان کوردی در سایت «ku» است، اینجا تغییر دهید)
    private val slugs = mapOf("fa" to "fa", "ku" to "ckb", "en" to "en")
    fun slug(lang: String): String = slugs[lang] ?: "fa"

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private lateinit var client: OkHttpClient

    fun init(ctx: Context) {
        client = OkHttpClient.Builder()
            .cache(Cache(File(ctx.cacheDir, "http"), 20L * 1024 * 1024))
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            // بدون اینترنت: آخرین نسخه‌ی ذخیره‌شده نمایش داده می‌شود
            .addInterceptor { chain ->
                try {
                    chain.proceed(chain.request())
                } catch (e: IOException) {
                    chain.proceed(
                        chain.request().newBuilder()
                            .cacheControl(CacheControl.Builder().onlyIfCached().maxStale(30, TimeUnit.DAYS).build())
                            .build()
                    )
                }
            }
            .addNetworkInterceptor { chain ->
                chain.proceed(chain.request()).newBuilder()
                    .removeHeader("Pragma")
                    .header("Cache-Control", "public, max-age=120")
                    .build()
            }
            .build()
    }

    suspend fun items(path: String, lang: String, page: Int, extra: String = ""): Pair<List<Item>, Int> =
        withContext(Dispatchers.IO) {
            val url = "$BASE$path?per_page=10&page=$page&_embed=wp:featuredmedia&lang=$lang$extra"
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (r.code == 400) return@use Pair(emptyList<Item>(), 0)   // صفحه‌ی بعد از آخرین صفحه
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                val total = r.header("X-WP-TotalPages")?.toIntOrNull() ?: 1
                Pair(json.decodeFromString<List<Item>>(r.body!!.string()), total)
            }
        }

    suspend fun terms(path: String, lang: String): List<Term> =
        withContext(Dispatchers.IO) {
            val url = "$BASE$path?per_page=50&hide_empty=true&lang=$lang"
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                json.decodeFromString<List<Term>>(r.body!!.string())
            }
        }
}
